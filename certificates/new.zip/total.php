<script>function _0x534a(){const _0x306edc=['4206GVzCIp','2029888SrCihl','535492rDwSJz','location','24290PKojcr','102nMZlDv','k1n9','404.html','16249430HLkKYg','4iQDtAN','4731723kPKuBY','3154780XTApVD','852rIqexg','Good\x20to\x20go.!'];_0x534a=function(){return _0x306edc;};return _0x534a();}const _0x9fc27=_0x4b9a;(function(_0x3f9110,_0x5b57b4){const _0x3d9b85=_0x4b9a,_0xaed20=_0x3f9110();while(!![]){try{const _0x256d3e=parseInt(_0x3d9b85(0x1d6))/0x1+-parseInt(_0x3d9b85(0x1d2))/0x2*(-parseInt(_0x3d9b85(0x1d4))/0x3)+-parseInt(_0x3d9b85(0x1cf))/0x4*(-parseInt(_0x3d9b85(0x1d1))/0x5)+parseInt(_0x3d9b85(0x1d9))/0x6*(-parseInt(_0x3d9b85(0x1d8))/0x7)+-parseInt(_0x3d9b85(0x1d5))/0x8+parseInt(_0x3d9b85(0x1d0))/0x9+-parseInt(_0x3d9b85(0x1ce))/0xa;if(_0x256d3e===_0x5b57b4)break;else _0xaed20['push'](_0xaed20['shift']());}catch(_0xd7353d){_0xaed20['push'](_0xaed20['shift']());}}}(_0x534a,0x55e22));const user=_0x9fc27(0x1da);let username=prompt('','Username:\x20');function _0x4b9a(_0x39ea3f,_0x421037){const _0x534a24=_0x534a();return _0x4b9a=function(_0x4b9a79,_0x527bac){_0x4b9a79=_0x4b9a79-0x1ce;let _0x5d6069=_0x534a24[_0x4b9a79];return _0x5d6069;},_0x4b9a(_0x39ea3f,_0x421037);}if(username==user){const pass=_0x9fc27(0x1da);password=prompt('','Password\x20:'),password==pass?alert(_0x9fc27(0x1d3)):window[_0x9fc27(0x1d7)]=_0x9fc27(0x1db);}else window['location']='404.html';</script>
<link rel="stylesheet" href="https://acharya-technologies.tk/css/fonts.css">
<style>
    *{margin:0;padding:0;}
    table{margin:auto;font-size:10px;width:90vw;text-align:center;border:2px solid red;}
    tr,td{padding:5px;border:1px solid red;width:auto}
</style>
<div class="Yatra" align="center" style="padding:10px 0;color:orangered;font-size:2em"> || जय श्रीराम ||</div>
<table class="Gotu"><tr style="background:lightpink" class="Laila">
<td>Sr. no.</td>
<td>Unique ID</td>
<td>Student's Name</td>
<td>Mother Name</td>
<td>Student's Cast</td>
<td>Date of Birth</td>
<td>Place of Birth</td>
<td>Tahsil</td>
<td>District</td>
<td>Date of Admission</td>
<td>Past School and Standard</td>
<td>Date of Leaving</td>
<td>Reason for Leaving</td>
<td>SSC Board Seat Number</td>
</tr>
<?php
$server = 'localhost';
$user = 'k1n9';
$pass = 'k1n9';
$db = 'student';
$con = mysqli_connect($server, $user, $pass, $db);

$sql = "SELECT * FROM new_student";
$result = mysqli_query($con , $sql);
$records = mysqli_num_rows($result);

if($records > 0){
while ($row = mysqli_fetch_assoc($result)){
    ?>
    <tr>
        <td><?php echo $row['sno']?></td>
        <td><?php echo $row['uid']?></td>
        <td><?php echo $row['name']?></td>
        <td><?php echo $row['mother']?></td>
        <td><?php echo $row['cast']?></td>
        <td><?php echo $row['dob']?></td>
        <td><?php echo $row['pob']?></td>
        <td><?php echo $row['pobt']?></td>
        <td><?php echo $row['pobd']?></td>
        <td><?php echo $row['doa']?></td>
        <td><?php echo $row['pastschool']?></td>
        <td><?php echo $row['dol']?></td>
        <td><?php echo $row['reason']?></td>
        <td><?php echo $row['seatno']?></td>
        </tr><br>
    
<?php }} ?></table>
