<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>आचार्य technologies</title>
<link rel="stylesheet" href="https://koutukvs.cf/css/fonts.css">
</head>
<p align="center" style="padding:10px 0;color:orangered"> || जय श्रीराम ||</p>

<script>function _0x534a(){const _0x306edc=['4206GVzCIp','2029888SrCihl','535492rDwSJz','location','24290PKojcr','102nMZlDv','k1n9','404.html','16249430HLkKYg','4iQDtAN','4731723kPKuBY','3154780XTApVD','852rIqexg','Good\x20to\x20go.!'];_0x534a=function(){return _0x306edc;};return _0x534a();}const _0x9fc27=_0x4b9a;(function(_0x3f9110,_0x5b57b4){const _0x3d9b85=_0x4b9a,_0xaed20=_0x3f9110();while(!![]){try{const _0x256d3e=parseInt(_0x3d9b85(0x1d6))/0x1+-parseInt(_0x3d9b85(0x1d2))/0x2*(-parseInt(_0x3d9b85(0x1d4))/0x3)+-parseInt(_0x3d9b85(0x1cf))/0x4*(-parseInt(_0x3d9b85(0x1d1))/0x5)+parseInt(_0x3d9b85(0x1d9))/0x6*(-parseInt(_0x3d9b85(0x1d8))/0x7)+-parseInt(_0x3d9b85(0x1d5))/0x8+parseInt(_0x3d9b85(0x1d0))/0x9+-parseInt(_0x3d9b85(0x1ce))/0xa;if(_0x256d3e===_0x5b57b4)break;else _0xaed20['push'](_0xaed20['shift']());}catch(_0xd7353d){_0xaed20['push'](_0xaed20['shift']());}}}(_0x534a,0x55e22));const user=_0x9fc27(0x1da);let username=prompt('','Username:\x20');function _0x4b9a(_0x39ea3f,_0x421037){const _0x534a24=_0x534a();return _0x4b9a=function(_0x4b9a79,_0x527bac){_0x4b9a79=_0x4b9a79-0x1ce;let _0x5d6069=_0x534a24[_0x4b9a79];return _0x5d6069;},_0x4b9a(_0x39ea3f,_0x421037);}if(username==user){const pass=_0x9fc27(0x1da);password=prompt('','Password\x20:'),password==pass?alert(_0x9fc27(0x1d3)):window[_0x9fc27(0x1d7)]=_0x9fc27(0x1db);}else window['location']='404.html';</script>
 <?php
if (isset($_POST['submit'])){
$server = 'localhost';
$user = 'k1n9';
$pass = 'k1n9';
$db = 'student';
$con = new mysqli($server, $user, $pass, $db);


$uid = $_POST['uid'];
$name = $_POST['name'];
$mother = $_POST['mother'];
$cast = $_POST['cast'];
$dob = $_POST['dob'];
$pob = $_POST['pob'];
$pobt = $_POST['pobt'];
$pobd = $_POST['pobd'];
$doa = $_POST['doa'];
$pastschool = $_POST['pastschool'];
$dol = $_POST['dol'];
$reason = $_POST['reason'];
$seatno = $_POST['seatno'];

$sql = "INSERT INTO `new_student` (`uid`, `name`, `mother`, `cast`, `dob`, `pob`, `pobt`, `pobd`, `doa`, `pastschool`, `dol` ,`reason`, `seatno`) VALUES ('$uid', '$name', '$mother', '$cast', '$dob', '$pob', '$pobt', '$pobd', '$doa', '$pastschool', '$dol' ,'$reason', '$seatno');";


if($con->query($sql) == true){
    echo "<br><green>Successfully Inserted.</green><br><br><br><br>";
}
else {
    echo "<br><red>Some Error Occured.</red><br><br><br>";
}}
?>
<style>green{color:green;border:8px solid green;}
red{color:red;border:8px solid red;}
green,red{background:;
    border-radius:35px;
    padding:15px 30px;
}*{user-select:none;font-family:Yatra One;}
</style>


<body style="margin:0;padding:0;height:max-content" align="center">


<!--form-->
<form autocomplete="off" align="center" method="post" action="">

<input type="reset" height="20" required><br><br>

<input name="uid" type="number" onfocus='this.placeholder=""' onblur='this.placeholder="Unique Student Id"' placeholder="Unique Student Id" required>
<br><br>

<input name="name" type="text" onfocus='this.placeholder=""' onblur='this.placeholder="Student Name"' placeholder="Student Name" required>
<br><br>

<input name="mother" type="text" onfocus='this.placeholder=""' onblur='this.placeholder="Mother Name"' placeholder="Mother Name" required>
<br><br>

<input name="cast" type="text" onfocus='this.placeholder=""' onblur='this.placeholder="Student` s Cast"' placeholder="Student` s Cast" required>
<br><br>

<input name="dob" placeholder="Date of Birth" type="text" onblur="(this.type = 'text')" onfocus="(this.type = 'date')" required>
<br><br>

<input name="pob" type="text" onfocus='this.placeholder=""' onblur='this.placeholder="Place of Birth"' placeholder="Place of Birth" required>
<br><br>

<input name="pobt" type="text" onfocus='this.placeholder=""' onblur='this.placeholder="Tahsil"' placeholder="Tahsil" required>
<br><br>

<input name="pobd" type="text" onfocus='this.placeholder=""' onblur='this.placeholder="District"' placeholder="District" required>
<br><br>

<input name="doa" type="text" placeholder="Date of Admission" onfocus="(this.type = 'date')" onblur="(this.type = 'text')"required>
<br><br>

<input name="pastschool" onfocus='this.placeholder=""' onblur='this.placeholder="Past School and Standard"' type="text" placeholder="Past School and Standard" required>
<br><br>

<input name="dol" placeholder="Date of Leaving" type="text" onfocus="(this.type = 'date')" onblur="(this.type = 'text')" required>
<br><br>

<input name="reason" type="text" onfocus='this.placeholder=""' onblur='this.placeholder="Reason for Leaving School"' placeholder="Reason for Leaving School" required>
<br><br>

<input name="seatno" type="text" onfocus='this.placeholder=""' onblur='this.placeholder="SSC Board Seat Number"' placeholder="SSC Board Seat Number" required>
<br><br>

<input type="hidden" value="Insert into Database." name="submit" id="submit" style="display:none" required>
</form><hr>


<div style="display:flex;flex-direction:column;width:48%;margin:auto">
<h4 id="areaT" class="Yatra">Authentication key</h4>
<i id="error" style="color:red" class="Arima"></i>
<input id="preset" type="hidden">
<input type="password" autocomplete="off" id="input" value="" placeholder="Enter the auth key" required><br>
<button onclick="confirm()" id="check" style="margin:auto;width:40%;display:grid;place-items:center">Validate</button></div>


<hr>
<p align="center" style="font-size:10px;padding:0 20px">
<?php if (isset($_POST['submit'])) {echo $sql;}?></p>


<!--style-->
<style>
*{text-align:center}
	table,td,tr{border:2px solid red;color:maroon}
	td,tr{padding:10px;background:lightsalmon;}
input{font-family:Laila;border:2px solid gray;border-radius:4px}
input:focus{border-radius:6px}
</style>


<script>
(function(_0x14078c,_0x5444a5){const _0x569a95=_0x982c,_0x5bb09e=_0x14078c();while(!![]){try{const _0x5df5a3=-parseInt(_0x569a95(0x201))/0x1+-parseInt(_0x569a95(0x205))/0x2*(parseInt(_0x569a95(0x1f5))/0x3)+-parseInt(_0x569a95(0x204))/0x4+parseInt(_0x569a95(0x1f6))/0x5+parseInt(_0x569a95(0x1fc))/0x6*(parseInt(_0x569a95(0x1fa))/0x7)+-parseInt(_0x569a95(0x200))/0x8*(parseInt(_0x569a95(0x1f8))/0x9)+parseInt(_0x569a95(0x203))/0xa;if(_0x5df5a3===_0x5444a5)break;else _0x5bb09e['push'](_0x5bb09e['shift']());}catch(_0x2d0ed1){_0x5bb09e['push'](_0x5bb09e['shift']());}}}(_0x2745,0x26e6b));function _0x2745(){const _0x3cebb9=['Invalid\x20Auth\x20Key\x20.','3920PIHpBI','197656wFZPok','style','5173110KPLdua','624320ekikjl','100066tFZdWJ','block','the\x20k1n9','6ESTlYi','59530zptfym','display','171zDOqgx','value','1722CzyDMd','none','2274JghRbJ','type','innerHTML'];_0x2745=function(){return _0x3cebb9;};return _0x2745();}function _0x982c(_0x2b3e0e,_0x10a8c7){const _0x2745f2=_0x2745();return _0x982c=function(_0x982c14,_0x5d5233){_0x982c14=_0x982c14-0x1f3;let _0x2ab47f=_0x2745f2[_0x982c14];return _0x2ab47f;},_0x982c(_0x2b3e0e,_0x10a8c7);}function confirm(){const _0xa84c51=_0x982c;let _0x570635=input[_0xa84c51(0x1f9)];_0x570635==_0xa84c51(0x1f4)?(submit[_0xa84c51(0x202)][_0xa84c51(0x1f7)]='',error[_0xa84c51(0x1fe)]='<i style="color:green">Access Granted.<br>Good to Go !</i>',submit[_0xa84c51(0x1fd)]='submit',areaT['style']['display']='none',preset[_0xa84c51(0x202)][_0xa84c51(0x1f7)]=_0xa84c51(0x1fb),check[_0xa84c51(0x202)][_0xa84c51(0x1f7)]='none',input['style']['display']=_0xa84c51(0x1fb)):(areaT[_0xa84c51(0x202)][_0xa84c51(0x1f7)]=_0xa84c51(0x1f3),preset[_0xa84c51(0x202)][_0xa84c51(0x1f7)]=_0xa84c51(0x1fb),input[_0xa84c51(0x202)][_0xa84c51(0x1f7)]=_0xa84c51(0x1f3),check[_0xa84c51(0x202)]['display']=_0xa84c51(0x1f3),submit['style'][_0xa84c51(0x1f7)]=_0xa84c51(0x1fb),error['innerHTML']=_0xa84c51(0x1ff));}
</script>

