<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#C2420D">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Koutuk Vidyalay,Shiroli (Pu.)</title>
<link rel="icon" type="image/x-icon" href="https://koutukvs.cf/img/favicon.ico">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://koutukvs.cf/css/style.css">
<link rel="stylesheet" href="https://koutukvs.cf/css/fonts.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<p align="center" class="Yatra text-center bg-orange-100 text-black"> || श्री ||</p>

<script>document.write(`
<body class="bg-orange-100 dark:bg-gray-700 text-black dark:text-white">

<!--header--><p align="center">
<header class="pb-8 pt-4 text-orange-600 body-font bg-orange-200 dark:bg-gray-900 Poppins w-screen border-b-4 border-b-orange-500 dark:border-b-green-700 shadow-inner shadow-lg">

<a href="https://koutukvs.cf/index.html" class="grid title-font place-center text-gray-900 ">
<p align="center"> <span class="logo grid m-auto justify-center "></span></p><br>
<span class="dark:text-green-600 text-orange-700 dark:hover:text-green-600 hover:text-orange-900 font-black text-4xl Yatra text-center">कौतुक विद्यालय, शिरोली</span></a><br>
<a target="_blank" href="https://koutukvs.cf/en" class="Gotu bg-orange-200 dark:bg-green-100 hover:bg-orange-500 dark:hover:bg-green-500 text-black hover:text-white py-1 border-4 text-xl font-black dark:border-green-500 border-orange-500 text-black rounded-lg m-auto relative px-4">Home</a>
</header></p>


<br><p align="center"><anim>KVS's Unique Id System</anim></p>
<!--main content-->
<form method="get" action="" align="center">
<input class="text-2xl focus:text-white dark:border-green-500 border-orange-400 dark:focus:bg-green-500 focus:bg-orange-400 text-orange-500 dark:text-green-600 font-black dark:bg-green-200 bg-orange-200 rounded-full border-4 w-80 mt-8 text-center h-12 Arima" placeholder="Enter your Unique ID" type="number" onfocus="this.placeholder='' " name="uid" value="<?php if(isset($_GET['uid'])){echo $_GET['uid'];}?>"  required min="1" max="9999">
<br><br>
<div class="flex justify-center">
<input id="preset" class="block dark:bg-green-200 dark:text-black bg-orange-200 border-2 dark:border-green-500 border-orange-600 rounded h-8 w-24 text-xl Yatra" readonly>
<i id="refresh" class="fa fa-refresh ml-1 text-xl mr-4 focus:mt-1 w-6 h-6 hover:animate-bounce dark:text-green-400 text-orange-500" onclick="capt()"></i>
<input id="input"  class="block dark:bg-gray-800 bg-orange-100 border-2 dark:border-green-500 border-orange-600 rounded h-8 w-48 font-serif" placeholder="Enter The CAPTCHA" required><br><br></div>
<input id="captBtn" onclick="confirm()" type="button" value="Check Captcha" class="border-2 dark:border-green-500 border-orange-600 rounded px-3 Arima h-8 dark:bg-green-800 bg-orange-300 text-lg block m-auto">
<input type="hidden" id="submit" value="Search" class="Laila bg-orange-200 hover:bg-orange-400 text-black hover:text-white py-2 border-4 text-xl font-black border-orange-400 text-black rounded-xl hidden m-auto relative w-24 bottom-16" required><br>
<i class="text-red-500 Tangerine text-4xl font-bold " id="error"></i>
</form><br>

<?php
$server = 'localhost';
$user = 'k1n9';
$pass = 'k1n9';
$db = 'student';
$con = mysqli_connect($server, $user, $pass, $db);

if(isset($_GET['uid'])){
        $uid = $_GET['uid'];
        $query = "SELECT * FROM new_student WHERE uid='$uid'";
        $query_run = mysqli_query($con,$query);
if(mysqli_num_rows($query_run) > 0){
        foreach($query_run as $row)
{?>
        <table align="center">
            <tr><th colspan="2">STUDENT DETAILS</th></tr>
            <tr>
                <td class="info">UID</td>
                <td><?php echo $row['uid']?></td>
            </tr>

            <tr>
                <td class="info">Name</td>
                <td><?php echo $row['name']?></td>
            </tr>

           <tr>
                <td class="info">Mother</td>
                <td><?php echo $row['mother']?></td>
            </tr>

            <tr>
                <td class="info">Cast</td>
                <td><?php echo $row['cast']?></td>
            </tr>

            <tr>
                <td class="info">Date of Birth</td>
                <td><?php echo $row['dob']?></td>
            </tr>

            <tr>
                <td class="info">Place of Birth</td>
                <td><?php echo $row['pob']?></td>
            </tr>

            <tr>
                <td class="info">Tahsil</td>
                <td><?php echo $row['pobt']?></td>
            </tr>

            <tr>
                <td class="info">District</td>
                <td><?php echo $row['pobd']?></td>
            </tr>

            <tr>
                <td class="info">Date of Admission</td>
                <td><?php echo $row['doa']?></td>
            </tr>

            <tr>
                <td class="info">Past School</td>
                <td><?php echo $row['pastschool']?></td>
            </tr>

            <tr>
                <td class="info">Date of Leaving</td>
                <td><?php echo $row['dol']?></td>
            </tr>

            <tr>
                <td class="info">Reason for Leaving School</td>
                <td><?php echo $row['reason']?></td>
            </tr>

            <tr>
                <td class="info">SSC Board Seat Number</td>
                <td><?php echo $row['seatno']?></td>
            </tr>

        </table><br>
<?php }}
else{echo "<div align='center'><b>&#9888; Student data not found.</b></div><br> ";}
}?>


<br>
<!--footer-->
<div class="relative w-screen text-center bottom-0 dark:text-white text-black text-center font-bold Amita">&copy Developed by
<span class="Gotu text-orange-500 font-bold text-xl"><a href="http://acharya-technologies.tk/">आचार्य <sub>Technologies.</sub></span><br></a></div><br><br><hr><br>
<div class="w-screen flex justify-evenly Laila">                                                                                                                         <div class="bottom-0 w-screen flex justify-evenly z-20 bg-orange-200 dark:bg-gray-900 border-t-4 border-orange-500 dark:border-green-700 items-center py-1 -mx-2 footer">
<a href="https://koutukvs.cf/contact.html"><img src="https://koutukvs.cf/img/favicon.ico" class="w-12 h-12 rounded-full">
<a href="https://maps.app.goo.gl/P5ahyCNPohLRwdJ9A" class="py-3 hover:text-blue-800">Visit Us</a>
<a href="tel:02302461633" class="py-3 hover:text-orange-500">Call Us</a>
<a href="https://koutukvs.cf/template/whatsapp.html" class="py-3 hover:text-green-600">Get in touch with <i class="fa fa-whatsapp"></i></a>
</div> </div>

`)</script>

<style>
*{text-align:center}
table{width:96vw}
tr,td{
	border:2px solid black;
	text-align:center;
	height:2em;
	width:20vmax;
	padding:5px;
	font-family:'Gotu';
	border-radius:10%;}
.info{
	font-weight:900;
	font-family:'Yatra One'}
b{
	background:#f78672;
	color:red;
	font-size:1.5em;
	padding:.2em .7em;}
anim{
	background:linear-gradient(45deg,orangered,orangered,orange,orange,white,orange,orange,orangered,orangered);
	font-family:Laila,cursive;
	-webkit-text-stroke-width:.5px;
	-webkit-text-stroke-color:black;
        background-size: 200% auto;
	-webkit-background-clip: text;
	color: transparent;
        font-weight:900;
	animation: textclip 2s linear infinite;
	font-size: 2em;}
@keyframes textclip {
0%{font-family:Gotu}
100% { background-position: 400% center;} }

</style>
<script src="https://koutukvs.cf/js/script.js"></script>
<script>
document.ready = capt();
function capt(){
const chars=["A","B","C","D","E","F","G","H","I","J","K","L","M",
                "N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
                "a","b","c","d","e","f","g","h","i","j","k","l","m",
                "n","o","p","q","r","s","t","u","v","w","x","y","z",
                "1","2","3","4","5","6","7","8","9","0","#","$"];

let a = chars[Math.floor(Math.random() * 64)];
let b = chars[Math.floor(Math.random() * 64)];
let c = chars[Math.floor(Math.random() * 64)];
let d = chars[Math.floor(Math.random() * 64)];
let e = chars[Math.floor(Math.random() * 64)];

preset.value = a + b + c + d + e;}

function confirm(){
let val1 = preset.value;
let val2 = input.value;
if (
	val1 == val2){submit.style.display = 'block';
	error.innerHTML = '';
	submit.type="submit";
	captBtn.style.display = "none";
	preset.style.display = "none";
	input.style.display ="none";
	refresh.style.display = 'none'}
else{
	captBtn.style.display="block";
	preset.style.display ="block";
	input.style.display  ="block";
        submit.style.display ="none";
        error.innerHTML = "Invalid &#160 Captcha";}
}
</script>
</body></html>

<noscript style="color:red;font-family:Amita"><br> Please enable
javascript in your browser setting.<br> It is disabled, <br>
Otherwise website won't work.<br><br> Thank You.</noscript>
